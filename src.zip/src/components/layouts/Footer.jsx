import React from 'react'

export default function Footer() {
  return (
    <>
    <footer>
<p className="text-center">
     All Copy Rights Reserved by Kiran Gajjala...
</p>
    </footer>
    </>
  );
}
